<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Soluciones HD</title>
</head>
<body>

    <h1>Módulo de Clientes</h1>

    <p>Bienvenido al sistema desarrollado con JSP.</p>

    <form action="ClienteServlet" method="post">

        Nombre:
        <input type="text" name="nombre">

        <br><br>

        <input type="submit" value="Enviar">

    </form>

</body>
</html>