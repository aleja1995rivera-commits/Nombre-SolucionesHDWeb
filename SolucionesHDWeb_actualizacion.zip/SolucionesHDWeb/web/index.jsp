<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <!-- Título de la página -->
    <title>Soluciones HD</title>

    <!-- Framework Bootstrap para mejorar el diseño -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<!-- Fondo claro para la página -->
<body class="bg-light">

    <!-- Contenedor principal -->
    <div class="container mt-5">

        <!-- Tarjeta principal -->
        <div class="card shadow">

            <!-- Encabezado -->
            <div class="card-header bg-primary text-white">
                <h3>Módulo de Clientes</h3>
            </div>

            <!-- Contenido -->
            <div class="card-body">

                <p>Bienvenido al sistema desarrollado con JSP.</p>

                <!-- Formulario que envía la información al Servlet mediante POST -->
                <form action="ClienteServlet" method="post">

                    <!-- Campo para ingresar el nombre -->
                    <div class="mb-3">

                        <label class="form-label">Nombre</label>

                        <input
                            type="text"
                            name="nombre"
                            class="form-control"
                            placeholder="Ingrese su nombre">

                    </div>

                    <!-- Botón para enviar el formulario -->
                    <button type="submit" class="btn btn-success">
                        Enviar
                    </button>

                </form>

            </div>

        </div>

    </div>

</body>
</html>