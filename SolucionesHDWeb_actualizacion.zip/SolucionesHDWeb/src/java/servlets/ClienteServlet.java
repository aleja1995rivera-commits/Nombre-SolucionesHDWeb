/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet encargado de atender las solicitudes del módulo de clientes.
 *
 * @author ORTIMA
 */
@WebServlet(name = "ClienteServlet", urlPatterns = {"/ClienteServlet"})
public class ClienteServlet extends HttpServlet {

    /**
     * Método generado por NetBeans para procesar solicitudes.
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ClienteServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ClienteServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    /**
     * Método GET.
     * Se ejecuta cuando el usuario realiza una petición mediante GET.
     */
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Configura el tipo de contenido de la respuesta
        response.setContentType("text/html;charset=UTF-8");

        // Permite escribir la respuesta en el navegador
        PrintWriter out = response.getWriter();

        // Generación de la página HTML
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Soluciones HD</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Bienvenido al módulo de clientes</h1>");
        out.println("<p>Este mensaje fue generado mediante el método GET.</p>");
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * Método POST.
     * Recibe la información enviada desde el formulario JSP.
     */
    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Configura el tipo de contenido de la respuesta
        response.setContentType("text/html;charset=UTF-8");

        // Obtiene el nombre enviado desde el formulario
        String nombre = request.getParameter("nombre");

        // Permite escribir la respuesta en el navegador
        PrintWriter out = response.getWriter();

        // Generación de la respuesta HTML
        out.println("<html>");
        out.println("<head>");
        out.println("<title>POST</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Formulario recibido correctamente</h1>");
        out.println("<p>Nombre recibido: <strong>" + nombre + "</strong></p>");
        out.println("<p>Este mensaje fue generado mediante el método POST.</p>");
        out.println("</body>");
        out.println("</html>");
    }
}